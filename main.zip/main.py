from flask import *
import sys
from data.db_session import global_init
from data.db_session import create_session
from data.users import User
from data.jobs import Jobs

app = Flask(__name__)
app.config["SEKRET_KEY"] = 'yandexlyceum_secret_key'


@app.route('/')
def main():
    lis = list()
    global_init('db/mars_exploers.db')
    session = create_session()
    for job in session.query(Jobs).all():
        user = session.query(User).filter(User.id == job.team_leader).first()
        fin = 'Is finished' if job.is_finished else 'Is not finished'
        lis.append(
            [job.job, user.surname + ' ' + user.name, f'{job.work_size} часов', job.collaborators, fin])
    return render_template('table.html', list_data=lis, n=len(lis))


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
